#opensea-nft-sniper
opensea nft sniper bot, feel free to fork and improve or whatever. 
you should be able to modify it to work on various exchanges
if you fork and modify please give credit
This is a tutorial to help run the opensea raribles coinbase nft sniper bot (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the opensea-raribles-coinbase-nft-sniper.zip anywhere you like.

Part 2. Editing the settings.

Open the bot folder find "config.js" file and open it with a text-editor:

1.Set your wallet address and private key or your wallet seed if you have a wallet that does not give you the private key

2.set the "marketplace" //1=Opensea , 2=Raribles , 3=coinbaseNFT

3.Set the "networks"  1 = ETH , 2 = Polygon

4.Set the "maxspend" max amount you want to spend ,but ammount "make sure you have the amount in your wallet you provided in config.js" 

5.Set the "NFTcollectionID" 
//for the opensea collection name "https://opensea.io/collection/boredapeyachtclub" <- take this part of the url for example: "boredapeyachtclub"
//for the Raribles "https://rarible.com/boredapeyachtclub/items" <- take this part of the url for example: "boredapeyachtclub"
//for the coinbaseNFT "https://nft.coinbase.com/collection/ethereum/0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D" <- take this part of the url for example: "0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D"
Happy hunting! :)

And When you make a big win and if you fill like thanking me my eth/bnb/polygon address is 0x2431bec69aa4699ad9A9aE77233F7bdcD6d631f8
